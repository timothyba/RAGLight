class Settings:
    CHROMA = "Chroma"
    OLLAMA = "Ollama"
    HUGGINGFACE = "HuggingFace"